/**
 * Created by Nick on 11/2/2016.
 */
var mongo8 = require('mongodb').mongo8;
var assert = require('assert');
var url = 'mongodb://nsigei:Motigo.355@ds057476.mlab.com:57476/lab8';
var insertDocument = function(db, callback) {
    db.collection('abc').insertOne( {
        "username" : "nick",
        "password" : "sigei.355",
    }, function(err, result) {
        assert.equal(err, null);
        console.log("Another User added");
        callback();
    });
};
mongo8.connect(url, function(err, db) {
    assert.equal(null, err);
    insertDocument(db, function() {
        db.close();
    });
});