
//Connection to MongoDb

var mongo8 = require('mongodb').mongo8;
var assert = require('assert');
var url = 'mongodb://nsigei:Motigo.355@ds023704.mlab.com:23704/mongo8';
mongo8.connect(url, function(err, db) {
    assert.equal(null, err);
    console.log("Connection Successful.");
    db.close();
});